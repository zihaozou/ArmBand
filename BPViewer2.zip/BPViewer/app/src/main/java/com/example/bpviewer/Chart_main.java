package com.example.bpviewer;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Observable;
import java.util.Observer;
import java.util.StringTokenizer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.nio.ByteBuffer;
import java.util.Arrays;
import androidx.annotation.RequiresApi;
import org.apache.commons.lang3.StringUtils;
import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Line;
import com.anychart.core.cartesian.series.Spline;
import com.anychart.data.Mapping;
import com.anychart.data.Set;
import com.anychart.enums.Anchor;
import com.anychart.enums.MarkerType;
import com.anychart.enums.ScaleTypes;
import com.anychart.enums.TooltipPositionMode;
import com.anychart.graphics.vector.Stroke;
import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleGattCallback;
import com.clj.fastble.callback.BleMtuChangedCallback;
import com.clj.fastble.callback.BleNotifyCallback;
import com.clj.fastble.callback.BleReadCallback;
import com.clj.fastble.callback.BleWriteCallback;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.exception.BleException;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Chart_main extends Fragment {
    private Button Device;
    private Button Start;
    private BleDevice ConnectedDevice;
    private UUID serviceUUID;
    private UUID characUUID;
    private UUID missingUUID;
    private List<DataEntry> seriesData = new ArrayList<>();
    private AnyChartView anyChartView;
    private Cartesian cartesian;
    private int lastnum;
    private ArrayList<Integer> missing;
    private boolean oneloopdone;
    private BluetoothGatt mygatt;
    private TextView BP_EST;


    @RequiresApi(api = Build.VERSION_CODES.M)
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.chart_main, container,false);
        Device=view.findViewById(R.id.Device);
        Start=view.findViewById(R.id.notify);
        BP_EST=view.findViewById(R.id.BP_est);
        Start.setEnabled(false);
        Device.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Device.setEnabled(false);
                DeviceListFragment devicelist = new DeviceListFragment();
                FragmentTransaction transaction=getFragmentManager().beginTransaction();
                transaction.replace(R.id.main_layout, devicelist);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });
        Start.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                    notifypi();
                }


        });
        if(ConnectedDevice!=null){
            Device.setEnabled(false);
            mygatt=BleManager.getInstance().connect(ConnectedDevice, new BleGattCallback() {
                @Override
                public void onStartConnect() {
                }

                @Override
                public void onConnectFail(BleDevice bleDevice, BleException exception) {
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(getActivity(), exception.toString(), duration);
                    toast.show();
                    ConnectedDevice=null;
                    Device.setEnabled(true);

                }
                @Override
                public void onConnectSuccess(BleDevice bleDevice, BluetoothGatt gatt, int status) {
                    seriesData.add(new CustomDataEntry(200, 4.1, 8.66));
                    mygatt=gatt;
                    List<BluetoothGattService> serviceList = mygatt.getServices();
                    for (BluetoothGattService service : serviceList) {
                        Log.d("service",service.getUuid().toString());
                        if(service.getUuid().toString().equals("00000001-710e-4a5b-8d75-3e5b444bc3cf")){
                            Log.d("service","service got");
                            serviceUUID = service.getUuid();
                            List<BluetoothGattCharacteristic> characteristicList= service.getCharacteristics();
                            for(BluetoothGattCharacteristic characteristic : characteristicList) {
                                Log.d("chara",characteristic.getUuid().toString());
                                if(characteristic.getUuid().toString().equals("00000002-710e-4a5b-8d75-3e5b444bc3cf")){
                                    Log.d("chara","ecgppg got");
                                    characUUID = characteristic.getUuid();}
                                if(characteristic.getUuid().toString().equals("ac08b9d1-c702-4cdb-b5ad-edb2f42ad7b9")){
                                    Log.d("chara","miss got");
                                    missingUUID = characteristic.getUuid();}
                            }
                        }


                    }
                    if(serviceUUID==null || characUUID==null || missingUUID==null){
                        CharSequence text = "Wrong Device";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(getActivity(), text, duration);
                        toast.show();
                        BleManager.getInstance().disconnect(ConnectedDevice);
                        Device.setEnabled(true);
                    }else{
                        CharSequence text = "Device Matched";
                        int duration = Toast.LENGTH_SHORT;
                        Toast toast = Toast.makeText(getActivity(), text, duration);
                        toast.show();
                        Start.setEnabled(true);
                    }
                    Start.setEnabled(true);
                }

                @Override
                public void onDisConnected(boolean isActiveDisConnected, BleDevice bleDevice, BluetoothGatt gatt, int status) {
                    CharSequence text = "Disconnected";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(getActivity(), text, duration);
                    toast.show();
                    ConnectedDevice=null;
                    Device.setEnabled(true);


                }
            });
        }

        anyChartView = view.findViewById(R.id.any_chart_view);
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int Wheight = displaymetrics.heightPixels;
        ViewGroup.LayoutParams params = anyChartView.getLayoutParams();
        params.height=(int) (Wheight*0.85);
        anyChartView.setLayoutParams(params);
        anyChartView.setBackgroundColor(0x6F6D5E);
        cartesian = AnyChart.line();
        cartesian.animation(true);
        cartesian.padding(10d, 20d, 5d, 20d);
        cartesian.crosshair().enabled(true);
        cartesian.crosshair()
                .yLabel(true)
                // TODO ystroke
                .yStroke((Stroke) null, null, null, (String) null, (String) null);

        cartesian.tooltip().positionMode(TooltipPositionMode.POINT);

        cartesian.title("ECG and PPG");
        cartesian.autoRedraw(true);
        cartesian.yAxis(0).title("value");
        cartesian.xAxis(0).labels().padding(5d, 5d, 5d, 5d);
        cartesian.xScale(ScaleTypes.LINEAR);
        seriesData.add(new CustomDataEntry(162, 3.6, 2.3));
        seriesData.add(new CustomDataEntry(164, 4.1, 2.7));
        Set set = Set.instantiate();
        set.data(seriesData);
        Mapping series1Mapping = set.mapAs("{ x: 'x', value: 'value' }");
        Mapping series2Mapping = set.mapAs("{ x: 'x', value: 'value2' }");

        Spline series1 = cartesian.spline(series1Mapping,"csv");
        series1.name("ECG");
        series1.hovered().markers().enabled(true);
        series1.hovered().markers()
                .type(MarkerType.CIRCLE)
                .size(4d);
        series1.tooltip()
                .position("right")
                .anchor(Anchor.LEFT_CENTER)
                .offsetX(5d)
                .offsetY(5d);

        Spline series2 = cartesian.spline(series2Mapping,"csv");
        series2.name("PPG");
        series2.hovered().markers().enabled(true);
        series2.hovered().markers()
                .type(MarkerType.CIRCLE)
                .size(4d);
        series2.tooltip()
                .position("right")
                .anchor(Anchor.LEFT_CENTER)
                .offsetX(5d)
                .offsetY(5d);
        cartesian.legend().enabled(true);
        cartesian.legend().fontSize(13d);
        cartesian.legend().padding(0d, 0d, 10d, 0d);
        anyChartView.setChart(cartesian);
        return view;

    }
    public void notifypi(){
        if (BleManager.getInstance().isConnected(ConnectedDevice)) {
            BleManager.getInstance().notify(
                    ConnectedDevice,
                    serviceUUID.toString(),
                    characUUID.toString(),
                    new BleNotifyCallback() {
                        @Override
                        public void onNotifySuccess() {
                            oneloopdone=false;
                            missing = new ArrayList<>();
                            lastnum = -1;
                            seriesData = new ArrayList<>();
                            CharSequence text = "notify success";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(getActivity(), text, duration);
                            toast.show();
                        }

                        @Override
                        public void onNotifyFailure(BleException exception) {
                            Log.d("dp", exception.toString());
                            CharSequence text = "notify failed";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(getActivity(), text, duration);
                            toast.show();
                        }

                        @Override
                        public void onCharacteristicChanged(byte[] data) {
                            if (processdata(data) == 1) {
                                BleManager.getInstance().stopNotify(ConnectedDevice,serviceUUID.toString(),
                                        characUUID.toString());
                                Log.d("stop notify","stop finished");
                                new Runnable () {
                                    @Override
                                    public void run() {
                                        if(oneloopdone==false) {
                                            oneloopdone=true;
                                            Set set = Set.instantiate();
                                            set.data(seriesData);
                                            Mapping series1Mapping = set.mapAs("{ x: 'x', value: 'value' }");
                                            Mapping series2Mapping = set.mapAs("{ x: 'x', value: 'value2' }");
                                            cartesian.getSeries(0).data(series1Mapping);
                                            cartesian.getSeries(1).data(series2Mapping);
                                            ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
                                            Runnable task = new Runnable() {
                                                public void run() {
                                                    notifypi ();
                                                }
                                            };
                                            int delay = 5;
                                            scheduler.schedule(task, delay, TimeUnit.SECONDS);
                                            scheduler.shutdown();
                                        }
                                    }
                                }.run ();

                            }
                        }
                    });
        }
    }
    public int processdata(byte[] data){
        String dataString=new String(data);
        dataString=dataString.replace("\n","");
        dataString=dataString.replace("\\s","");
        String[] dataPkg= dataString.split(";");

        float avepttb = 0;
        float avepttt = 0;
        double SBP = 0;
        double DBP = 0;
        float pttb_sum = 0; //SBP peak to bottom
        float pttt_sum = 0; //DBP peak to peak
        float current_ecg_peak_time = 0;
        int pttb_cnt = 0;
        int pttt_cnt = 0;

        for(String a:dataPkg){
            Log.d("data",a);
            if(a.equals("end")){
                Log.d("end","end");
                return 1;
            }else{
                int nownum=Integer.parseInt(a.split(":")[0]);
                if(nownum==lastnum+1){
                    lastnum=nownum;
                }
                else if(nownum>lastnum+1){
                    for(int y=lastnum;y<nownum;y++){
                        missing.add(y);
                    }
                    lastnum=nownum;
                }
                String[] dataSet=a.split(":")[1].split("!");
                for(String x:dataSet){
                    String[] f=x.split(",");
                    float time=Float.parseFloat(f[0]);
                    float ecg=Float.parseFloat(f[1]);
                    float ppg=Float.parseFloat(f[2]);
                    int ecg_peak = Integer.parseInt(f[3]);
                    int ppg_peak = Integer.parseInt(f[4]);
                    int ppg_bottom = Integer.parseInt(f[5]);
                    if (ecg_peak==1){
                        current_ecg_peak_time = time;
                    }
                    if(ppg_peak==1 && current_ecg_peak_time!=0){
                        pttt_sum += time-current_ecg_peak_time;
                        pttt_cnt++;
                    }
                    if(ppg_bottom==1 && current_ecg_peak_time!=0){
                        pttb_sum += time-current_ecg_peak_time;
                        pttb_cnt++;
                    }
                    seriesData.add(new CustomDataEntry(time,ecg,ppg));
                }
                if(pttb_cnt>0){
                    avepttb = pttb_sum / pttb_cnt;
                    SBP = -0.241 * avepttb + 115.3;
                }
                if(pttt_cnt>0){
                    avepttt = pttt_sum / pttt_cnt;
                    DBP = -0.1253 * avepttt + 70.87;
                }
            }
        }

        String display = "DBP: " + DBP + " SBP: "+ SBP;

        BP_EST.setText(display);

        return 0;
    }
    public void setConnectedDevice(BleDevice connectedDevice) {
        this.ConnectedDevice = connectedDevice;
    }

    class CustomDataEntry extends ValueDataEntry {

        CustomDataEntry(Number x, Number value, Number value2) {
            super(x, value);
            setValue("value2",value2);

        }
    }


}
