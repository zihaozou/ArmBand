package com.example.plottest;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.androidplot.Plot;
import com.androidplot.util.PixelUtils;
import com.androidplot.xy.XYSeries;
import com.androidplot.xy.*;

import java.text.DecimalFormat;
import java.util.Observable;
import java.util.Observer;

public class MainActivity extends AppCompatActivity {
    BTReceiver btReceiver;
    private XYPlot EGGPlot;
    MyPlotUpdater myPlotUpdater;
    Button BT;
    Button Devices;
    Button Start;

    private class MyPlotUpdater implements Observer {
        Plot plot;

        public MyPlotUpdater(Plot plot) {
            this.plot = plot;
        }

        @Override
        public void update(Observable o, Object arg) {
            plot.redraw();
        }
    }

    class EGGSeries implements XYSeries{
        private String Title;
        private BTReceiver.DataReceive dr;
        private final int SAMPLE_SIZE=100;
        public EGGSeries(String title,BTReceiver btr){this.Title=title;dr=btr.dataReceive;}
        public String getTitle() { return this.Title; }
        public int size() { return SAMPLE_SIZE; }
        public Number getX(int index){if (index >= SAMPLE_SIZE) {
            throw new IllegalArgumentException();
        }return index;}
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public Number getY(int index) {if (index >= SAMPLE_SIZE) {
            throw new IllegalArgumentException();
        }return dr.getY(index);}

    }



    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        EGGPlot = (XYPlot) findViewById(R.id.plot);
        myPlotUpdater = new MyPlotUpdater(EGGPlot);
        btReceiver=new BTReceiver();
        btReceiver.contex=this;
        btReceiver.activity=this;
        /*set button*/
        BT = findViewById(R.id.BT);
        Devices=findViewById(R.id.Devices);
        Start=findViewById(R.id.Start);
        BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btReceiver.OpenBT();
            }
        });
        Devices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btReceiver.SelectDevice();

            }
        });
        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String starttext= "Start";
                btReceiver.SendMessage(starttext.getBytes());
                btReceiver.dataReceive.addObserver(myPlotUpdater);
            }
        });
        Log.d("Creating","Creating Series");
        EGGSeries eggSeries=new EGGSeries("EGG",btReceiver);
        LineAndPointFormatter formatter1 = new LineAndPointFormatter(
                Color.rgb(0, 200, 0), null, null, null);
        formatter1.getLinePaint().setStrokeJoin(Paint.Join.ROUND);
        formatter1.getLinePaint().setStrokeWidth(10);
        Log.d("ADD","ADDing Series");
        EGGPlot.addSeries(eggSeries, formatter1);

        EGGPlot.setDomainStepMode(StepMode.INCREMENT_BY_VAL);
        EGGPlot.setDomainStepValue(20);
        EGGPlot.setRangeStepMode(StepMode.INCREMENT_BY_VAL);
        EGGPlot.setRangeStepValue(0.04);
        EGGPlot.getGraph().getLineLabelStyle(
                XYGraphWidget.Edge.LEFT).setFormat(new DecimalFormat("###.#"));
        EGGPlot.setRangeBoundaries(-0.4,0.4,BoundaryMode.FIXED);
        DashPathEffect dashFx = new DashPathEffect(
                new float[] {PixelUtils.dpToPix(3), PixelUtils.dpToPix(3)}, 0);
        EGGPlot.getGraph().getDomainGridLinePaint().setPathEffect(dashFx);
        EGGPlot.getGraph().getRangeGridLinePaint().setPathEffect(dashFx);
    }






}
