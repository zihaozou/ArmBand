package com.example.plottest;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.androidplot.Plot;
import com.androidplot.util.PixelUtils;
import com.androidplot.xy.XYSeries;
import com.androidplot.xy.*;

import java.text.DecimalFormat;
import java.util.Observable;
import java.util.Observer;

public class MainActivity extends AppCompatActivity {
    BTReceiver btReceiver;
    private XYPlot EGGPlot;
    private XYPlot RespPlot;
    MyPlotUpdater myPlotUpdater;
    Button BT;
    Button Devices;
    Button Start;

    private class MyPlotUpdater implements Observer {
        Plot plot;
        Plot plot2;
        public MyPlotUpdater(Plot plot,Plot plot2) {
            this.plot = plot;
            this.plot2 = plot2;
        }

        @Override
        public void update(Observable o, Object arg) {
            plot.redraw();
            plot2.redraw();
        }
    }

    class EGGSeries implements XYSeries{
        private int series;
        private String Title;
        private BTReceiver.DataReceive dr;
        public EGGSeries(String title,BTReceiver btr,int series){this.Title=title;dr=btr.dataReceive;this.series=series;}
        public String getTitle() { return this.Title; }
        public int size() {
            if (series==1) {
                return btReceiver.Data.size();
            }
            else if (series==2)
            {
                return btReceiver.Data2.size();
            }
            else
            {return 0;}
        }
        public Number getX(int index){if (index > btReceiver.Data.size()) {
            throw new IllegalArgumentException();
        }return index;}
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public Number getY(int index) {if (index > btReceiver.Data.size()) {
            throw new IllegalArgumentException();
        }
        if (series==1){return dr.getCh1Y(index);}
        else {return dr.getCh2Y(index);}}

    }



    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        RespPlot = (XYPlot) findViewById(R.id.plot2);
        EGGPlot = (XYPlot) findViewById(R.id.plot);
        myPlotUpdater = new MyPlotUpdater(EGGPlot,RespPlot);
        btReceiver=new BTReceiver();
        btReceiver.contex=this;
        btReceiver.activity=this;
        /*set button*/
        BT = findViewById(R.id.BT);
        Devices=findViewById(R.id.Devices);
        Start=findViewById(R.id.Start);
        BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btReceiver.OpenBT();
            }
        });
        Devices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btReceiver.SelectDevice();

            }
        });
        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String starttext= "Start";
                btReceiver.SendMessage(starttext.getBytes());
                btReceiver.dataReceive.addObserver(myPlotUpdater);
            }
        });
        Log.d("Creating","Creating Series");
        EGGSeries ecgSeries=new EGGSeries("ECG",btReceiver,2);
        LineAndPointFormatter formatter1 = new LineAndPointFormatter(
                Color.rgb(0, 200, 0), null, null, null);
        formatter1.getLinePaint().setStrokeJoin(Paint.Join.ROUND);
        formatter1.getLinePaint().setStrokeWidth(3);
        EGGSeries resSeries=new EGGSeries("RESP",btReceiver,1);
        LineAndPointFormatter formatter2 = new LineAndPointFormatter(
                Color.rgb(200, 0, 0), null, null, null);
        formatter2.getLinePaint().setStrokeJoin(Paint.Join.ROUND);
        formatter2.getLinePaint().setStrokeWidth(3);
        RespPlot.addSeries(resSeries, formatter2);

        Log.d("ADD","ADDing Series");
        EGGPlot.addSeries(ecgSeries, formatter1);

        EGGPlot.setDomainStepMode(StepMode.INCREMENT_BY_VAL);
        EGGPlot.setDomainStepValue(20);
        EGGPlot.setRangeStepMode(StepMode.INCREMENT_BY_VAL);
        EGGPlot.setRangeStepValue(0.5);
        EGGPlot.getGraph().getLineLabelStyle(
                XYGraphWidget.Edge.LEFT).setFormat(new DecimalFormat("###.#"));
        EGGPlot.setRangeBoundaries(-0.7,0.3,BoundaryMode.FIXED);
        EGGPlot.setDomainBoundaries(0,100, BoundaryMode.FIXED);
        DashPathEffect dashFx = new DashPathEffect(
                new float[] {PixelUtils.dpToPix(3), PixelUtils.dpToPix(3)}, 0);
        EGGPlot.getGraph().getDomainGridLinePaint().setPathEffect(dashFx);
        EGGPlot.getGraph().getRangeGridLinePaint().setPathEffect(dashFx);

        RespPlot.setDomainStepMode(StepMode.INCREMENT_BY_VAL);
        RespPlot.setDomainStepValue(20);
        RespPlot.setRangeStepMode(StepMode.INCREMENT_BY_VAL);
        RespPlot.setRangeStepValue(0.5);
        RespPlot.getGraph().getLineLabelStyle(
                XYGraphWidget.Edge.LEFT).setFormat(new DecimalFormat("###.#"));
        RespPlot.setRangeBoundaries(1,1.5,BoundaryMode.FIXED);
        RespPlot.setDomainBoundaries(0,100, BoundaryMode.FIXED);
        RespPlot.getGraph().getDomainGridLinePaint().setPathEffect(dashFx);
        RespPlot.getGraph().getRangeGridLinePaint().setPathEffect(dashFx);
    }






}
