package com.example.plottest;
import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
public class BTReceiver{
    private BluetoothAdapter BTAdapter;
    private Intent BTEnabling_intent;
    private int BTEnalbe_requestCode;
    public BluetoothDevice[] btArray;
    public Activity activity;
    public ListView dialogListView;
    public Context contex;
    public UUID MY_UUID= UUID.randomUUID();
    public BluetoothSocket bluetoothSocket;
    public InputStream inputStream;
    public OutputStream outputStream;
    public List <String> Data=new ArrayList<String>();
    public DataReceive dataReceive;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public BTReceiver(){
        this.BTAdapter=BluetoothAdapter.getDefaultAdapter();
        this.BTEnabling_intent=new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        this.BTEnalbe_requestCode=1;
        this.dataReceive =new DataReceive();
        for (int i=0;i<101;i++)
        {
            Data.add("0");
        }
    }
    public void OpenBT(){
        if(!BTAdapter.isEnabled()){
            activity.startActivityForResult(BTEnabling_intent, BTEnalbe_requestCode);
        }else if (BTAdapter.isEnabled()){
            Toast.makeText(activity.getApplicationContext(), "Bluetooth is already ON", Toast.LENGTH_LONG).show();
        }
    }
    public void SelectDevice(){
        this.OpenBT();
        Set<BluetoothDevice> btDeviceSet = BTAdapter.getBondedDevices();
        String[] deviceStrings = new String[btDeviceSet.size()];
        this.btArray = new BluetoothDevice[btDeviceSet.size()];
        int index = 0;

        if(btDeviceSet.size() > 0){
            for(BluetoothDevice device : btDeviceSet){
                btArray[index] = device;
                deviceStrings[index] = device.getName();
                index++;
            }
            ArrayAdapter <String> arrayAdapter = new ArrayAdapter<String>(activity.getApplicationContext(), android.R.layout.simple_list_item_1, deviceStrings);

            final Dialog dialog = new Dialog(contex);
            dialog.setContentView(R.layout.list_dialog);
            dialog.setTitle("Choose Device");
            dialogListView= (ListView) dialog.findViewById(R.id.dialog_List);
            dialogListView.setAdapter(arrayAdapter);
            dialog.show();
            dialogListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l){
                    ClientClass clientClass = new ClientClass(btArray[i]);
                    clientClass.start();
                    dialog.dismiss();
                }
            });
        }

    }
    private class ClientClass extends Thread{
        private BluetoothDevice device;
        private BluetoothSocket socket;

        ClientClass(BluetoothDevice device1){
            device = device1;
            try{
                socket = device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e){
                e.printStackTrace();
            }
            bluetoothSocket=socket;
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        public void run(){
            try{
                socket.connect();
            } catch (IOException e){
                try {
                    socket =(BluetoothSocket) device.getClass().getMethod("createRfcommSocket", new Class[] {int.class}).invoke(device,1);
                    socket.connect();
                    Log.d("connect",Boolean.toString(socket.isConnected()));
                    InputStream tempIn = null;
                    OutputStream tempOut = null;
                    try {
                        tempIn = socket.getInputStream();
                        tempOut = socket.getOutputStream();
                        Log.d("Creating","Creating outputstream");
                    } catch (IOException y) {
                        y.printStackTrace();
                    }
                    Log.d("connect",Boolean.toString(socket.isConnected()));
                    inputStream = tempIn;
                    outputStream = tempOut;
                    dataReceive.start();
                    Log.d("Creating","Creating outputstream");
                } catch (IllegalAccessException e1) {
                    e1.printStackTrace();

                } catch (InvocationTargetException e1) {
                    e1.printStackTrace();
                } catch (NoSuchMethodException e1) {
                    e1.printStackTrace();

                } catch (IOException e1) {
                    e1.printStackTrace();

                }
            }
        }
    }
    public void SendMessage(byte[] bytes){
        try {
            outputStream.write(bytes);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }





    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public class DataReceive extends Thread{
        Charset charset = StandardCharsets.UTF_8;

        class MyObservable extends Observable {
            @Override
            public void notifyObservers() {
                setChanged();
                super.notifyObservers();
            }
        }
        private MyObservable myObservable=new MyObservable();

        public void run() {
            byte [] buffer = new byte[1024];
            int count = 0;

            while (true){
                String q=null;
                Log.d("Trying","Try to Receive Data");
                while (true){
                    try {
                        if ((count = inputStream.read(buffer)) >= 0) break;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                SendMessage("OK".getBytes());
                if(Data.size()>=100)
                {
                    Data.remove(1);
                }
                q= new String(buffer,0,count);
                Log.d("Value",q);
                Data.add(q);
                myObservable.notifyObservers();
            }
        }
        public double getY(int index){return Double.parseDouble(Data.get(index));};
        public void addObserver(Observer observer) {
            myObservable.addObserver(observer);
        }

        public void removeObserver(Observer observer) {
            myObservable.deleteObserver(observer);
        }
    }






}
