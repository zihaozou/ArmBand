package com.example.bpviewer;

import android.Manifest;
import android.app.FragmentTransaction;
import android.bluetooth.BluetoothGatt;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.app.Fragment;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleGattCallback;
import com.clj.fastble.callback.BleScanCallback;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.exception.BleException;
import com.clj.fastble.scan.BleScanRuleConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class DeviceListFragment extends Fragment {
    private static final int READ_PHONE_STATE = 100;
    private Button ScanBtn;
    private ListView devicelst;



    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.device_list, container,false);
        devicelst=view.findViewById(R.id.deivcelst);
        DisplayMetrics displaymetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int Wheight = displaymetrics.heightPixels;
        ViewGroup.LayoutParams params = view.findViewById(R.id.deivcelst).getLayoutParams();
        params.height=(int) (Wheight*0.9);
        view.findViewById(R.id.deivcelst).setLayoutParams(params);
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},
                    READ_PHONE_STATE);
        }
        BleScanRuleConfig scanRuleConfig = new BleScanRuleConfig.Builder().build();
        BleManager.getInstance().initScanRule(scanRuleConfig);
        ScanBtn=view.findViewById(R.id.scan_stop);



        ScanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScanBtn.setText("Scanning");
                ScanBtn.setEnabled(false);

                BleManager.getInstance().scan(new BleScanCallback() {
                    public void onScanStarted(boolean success) {
                    }
                    @Override
                    public void onScanning(BleDevice bleDevice) {
                    }
                    @Override
                    public void onScanFinished(List<BleDevice> scanResultList) {
                        ScanBtn.setText("Scan");
                        ScanBtn.setEnabled(true);
                        ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String, Object>>();
                        for(BleDevice a : scanResultList){
                            HashMap<String, Object> map = new HashMap<String, Object>();
                            map.put("devicename",(a.getName()==null)?a.getMac():a.getName());
                            listItem.add(map);
                        }
                        MyAdapter adapter = new MyAdapter(ScanBtn.getContext(), listItem,scanResultList);
                        devicelst.setAdapter(adapter);
                    }
                });
            }});

        return view;
    }
    private class MyAdapter extends BaseAdapter {
        private LayoutInflater mInflater;
        private ArrayList<HashMap<String, Object>> listItem;
        private List<BleDevice> deivces;
        public MyAdapter(Context context, ArrayList<HashMap<String, Object>> listItem, List<BleDevice> deivces) {
            this.mInflater = LayoutInflater.from(context);
            this.listItem = listItem;
            this.deivces=deivces;
        }
        public int getCount() {
            return listItem.size();
        }

        @Override
        public Object getItem(int position) {
            return listItem.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        class ViewHolder
        {
            public TextView name;
        }
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if(convertView == null)
            {
                holder = new ViewHolder();
                convertView = mInflater.inflate(R.layout.device_info, null);
                holder.name= (TextView) convertView.findViewById(R.id.deviceitem);
                convertView.setTag(holder);
            }
            else {
                holder = (ViewHolder)convertView.getTag();
            }
            holder.name.setText((String)listItem.get(position).get("devicename"));
            holder.name.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v) {
                    Chart_main cm= (Chart_main) getActivity().getFragmentManager().findFragmentByTag("chart");
                    cm.setConnectedDevice(deivces.get(position));
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.main_layout, cm);
                    transaction.commit();
            }});
            return convertView;
        }

    }

}
